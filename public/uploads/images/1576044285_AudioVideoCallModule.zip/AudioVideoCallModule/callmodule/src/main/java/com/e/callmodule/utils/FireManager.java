package com.e.callmodule.utils;

public class FireManager {

    //Get this user's uid
    public static String getUid() {
        return SharedPreferencesManager.getUid();
    }
}