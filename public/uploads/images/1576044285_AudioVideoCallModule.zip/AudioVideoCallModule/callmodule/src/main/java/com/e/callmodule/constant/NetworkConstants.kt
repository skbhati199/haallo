package com.e.callmodule.constant

interface NetworkConstants {
    companion object {
        private const val IP_ADDRESS = "haallo-app.fluper.in"
        const val BASE_URL = "http://$IP_ADDRESS/"
        const val BASE_IMAGE_URL = "http://$IP_ADDRESS"
        const val SEND_CALL_NOTIFICATION = "api/callingRequest"
        const val SEND_NOTIFICATION_TOPIC= "api/groupCallingRequest"
    }
}