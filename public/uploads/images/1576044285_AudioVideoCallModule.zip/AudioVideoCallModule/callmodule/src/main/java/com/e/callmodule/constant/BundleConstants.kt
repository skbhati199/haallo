package com.e.callmodule.constant

object BundleConstants {

    @JvmField
    val KEY_GROUP_ID = "group_id"
    @JvmField
    val KEY_OTHER_ID = "other_id"
    val TOPIC = "topic"
    val KEY_IS_CLUB = "is_club"

    @JvmField
    val KEY_GROUP_NAME = "group_name"


    @JvmField
    val KEY_CALL_ID = "call_id"
    @JvmField
    val KEY_OTHER_NAME = "other_name"
    @JvmField
    val KEY_OTHER_AVATAR = "other_avatar"

    @JvmField
    val KEY_CALL_TYPE = "call_type"
    @JvmField
    val KEY_CALL_STATUS = "call_status"

    @JvmField
    val KEY_LOAD_CHAT = "load_chat"

    const val KEY_IMAGE = "image"

    const val KEY_LIST = "list"
    const val KEY_INDEX = "index"
}