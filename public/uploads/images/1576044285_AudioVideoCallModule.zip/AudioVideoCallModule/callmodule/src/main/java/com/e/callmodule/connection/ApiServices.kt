package com.e.callmodule.connection

import com.e.callmodule.constant.NetworkConstants
import com.e.callmodule.response.NotificationRes
import com.e.callmodule.response.RegistrationRes
import io.reactivex.Observable
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Header
import retrofit2.http.POST

interface ApiServices {
    //Match Contact List
    @FormUrlEncoded
    @POST(NetworkConstants.SEND_CALL_NOTIFICATION)
    fun sendCallNotification(
        @Header("accessToken") accessToken: String,
        @Field("send_to_id") send_to_id: String,
        @Field("title") title: String,
        @Field("notification_type") notification_type: String,
        @Field("call_id") call_id: String,
        @Field("message") message: String,
        @Field("full_name") full_name: String,
        @Field("profile_pic") profile_pic: String
    ): Observable<NotificationRes>

    @FormUrlEncoded
    @POST(NetworkConstants.SEND_NOTIFICATION_TOPIC)
    fun sendNotificationTopic(
        @Header("accessToken") accessToken: String,
        @Field("send_to_id") send_to_id: String,
        @Field("title") title: String,
        @Field("notification_type") notification_type: String,
        @Field("call_id") call_id: String,
        @Field("message") message: String,
        @Field("full_name") full_name: String,
        @Field("profile_pic") profile_pic: String,
        @Field("user_id[]") user_id: List<String>
    ): Observable<RegistrationRes>
}