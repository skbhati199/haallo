package com.e.callmodule.activity

import android.Manifest
import android.app.Dialog
import android.app.KeyguardManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.media.MediaPlayer
import android.os.*
import android.util.Log
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.e.callmodule.R
import com.e.callmodule.constant.BundleConstants
import com.e.callmodule.constant.NetworkConstants
import com.e.callmodule.model.OneCallDetail
import com.e.callmodule.response.NotificationRes
import com.e.callmodule.utils.EnumUtils
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas
import io.agora.rtc.video.VideoEncoderConfiguration
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import retrofit2.HttpException

class AudioVideoCallActivity : BaseActivityForCall(), View.OnClickListener, CallReviewListener {

    private var callAccept: Boolean = false
    private val handler: Handler = Handler()
    private var incomingCallDialog: Dialog? = null
    private var verificationDisposable: Disposable? = null
    //   var dtmfGenerator: ToneGenerator = ToneGenerator(AudioManager.STREAM_RING, ToneGenerator.MAX_VOLUME)

    private lateinit var mService: AudioService
    private var mBound: Boolean = false

    private lateinit var mp: MediaPlayer
    private lateinit var callType: EnumUtils.CallType

    private val callStatus: EnumUtils.CallStatus
        get() = intent.getSerializableExtra(BundleConstants.KEY_CALL_STATUS) as EnumUtils.CallStatus

    private val otherId: String?
        get() = intent.getStringExtra(BundleConstants.KEY_OTHER_ID)

    private val otherName: String?
        get() = intent.getStringExtra(BundleConstants.KEY_OTHER_NAME)

    private val otherAvatar: String?
        get() = intent.getStringExtra(BundleConstants.KEY_OTHER_AVATAR)

    private val image: String?
        get() = intent.getStringExtra(BundleConstants.KEY_IMAGE)

    private val callId: String?
        get() = intent.getStringExtra(BundleConstants.KEY_CALL_ID)

    private var mRtcEngine: RtcEngine? = null

    private var callHandle: Boolean = true
    private val channelName: String by lazy {
        arrayOf(otherId!!.replace("u_", ""), SharedPreferenceUtil.getInstance(this).userId.toString()).sortedArray()
            .joinToString("_")
    }

    companion object {
        private val TAG = AudioVideoCallActivity::class.simpleName!!
        private const val RC_PERM_CALL = 201
        private val REQUESTED_PERMISSIONS = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
    }

    private val mConnection = object : ServiceConnection {

        override fun onServiceConnected(componentName: ComponentName, service: IBinder) {
            Log.d(TAG, "onServiceConnected() >> componentName: $componentName \n binder: $service")
            val binder = service as AudioService.LocalBinder
            mService = binder.getService()
            mBound = true
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            Log.d(TAG, "onServiceDisconnected() >> componentName: $componentName")
            mBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)
        setContentView(R.layout.activity_video_chat)
        init(savedInstanceState)
        initControl()
    }

    private fun isVideoCall() = callType == EnumUtils.CallType.VIDEO_CALL
    private fun isVoiceCall() = callType == EnumUtils.CallType.AUDIO_CALL

    override fun init(savedInstanceState: Bundle?) {
        mp = MediaPlayer.create(this, R.raw.samsung_original)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        /* https://stackoverflow.com/a/50159747 */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            this.window.addFlags(
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        /* Initializing bundle data */
        callType = intent.getSerializableExtra(BundleConstants.KEY_CALL_TYPE) as EnumUtils.CallType

        // making them disable until remote user joined.
        iv_voice_call_mute.isEnabled = false
        //  iv_chat.isEnabled = false
        //iv_video_call.isEnabled = false

        iv_video_call_mute.isEnabled = false

        resetViewsVisibility()

        if (isVoiceCall()) {
            Glide.with(this).load(NetworkConstants.BASE_IMAGE_URL + otherAvatar)
                .placeholder(R.drawable.user_placeholder).into(iv_user_image)
            Glide.with(this).load(NetworkConstants.BASE_IMAGE_URL + otherAvatar).into(iv_back_image)

            /*iv_user_image.loadImage(
                ApiConstant.IMAGE_BASE_URL+otherAvatar,
                true,
                false,
                false,
                false,
                10,
                R.drawable.com_facebook_profile_picture_blank_square,
                R.drawable.com_facebook_profile_picture_blank_square)*/
        }

        when (callStatus) {
            EnumUtils.CallStatus.INCOMING -> showIncomingCallDialog()
            EnumUtils.CallStatus.OUTGOING -> {
                //showShortToast(this, "Calling $otherName...")
                //dtmfGenerator.startTone(ToneGenerator.TONE_DTMF_0, 50000)
                when (callType) {
                    EnumUtils.CallType.VIDEO_CALL -> sendNotification(
                        EnumUtils.NotificationType.VIDEO_CALL_INCOMING.value,
                        "Video Call"
                    )
                    EnumUtils.CallType.AUDIO_CALL -> sendNotification(
                        EnumUtils.NotificationType.AUDIO_CALL_INCOMING.value,
                        "Audio Call"
                    )
                }
                if (checkSelfPermission(REQUESTED_PERMISSIONS[0], RC_PERM_CALL) && checkSelfPermission(
                        REQUESTED_PERMISSIONS[1],
                        RC_PERM_CALL
                    )
                )
                    initAgoraEngineAndJoinChannel()
            }
        }
    }

    fun onLocalAudioMuteClicked(view: View) {
        mRtcEngine?.let {
            val iv = view as ImageView
            if (iv.isSelected) {
                iv.isSelected = false
                iv.clearColorFilter()
                // tv_voice_mute.text = "mute"
            } else {
                iv.isSelected = true
                iv.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.MULTIPLY)
                //  tv_voice_mute.text = "unmute"
            }
            it.muteLocalAudioStream(iv.isSelected)
        }
    }

    fun onSwitchToVideoCallClicked(@Suppress("UNUSED_PARAMETER") view: View) {
        //ToastUtils.show(this, "Waiting for $otherName to respond")
        sendNotification(EnumUtils.NotificationType.A2V_SWAP_REQ_INCOMING.value, "Video Call")
        callType = EnumUtils.CallType.VIDEO_CALL
        resetViewsVisibility()
//        mRtcEngine?.setDefaultAudioRoutetoSpeakerphone(true)
        mRtcEngine?.setEnableSpeakerphone(true)
        setupVideoProfile()
        setupLocalVideo()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Destroying activity & leaving channel...")
        mRtcEngine?.leaveChannel()
        //  myRef.setValue(EnumUtils.UserCallStatus.IDLE.value)
        RtcEngine.destroy()
    }

    fun onLocalVideoMuteClicked(view: View) {
        mRtcEngine?.let {
            val iv = view as ImageView
            if (iv.isSelected) {
                iv.isSelected = false
                iv.clearColorFilter()
                //   tv_video_mute.text = "mute"
            } else {
                iv.isSelected = true
                iv.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.MULTIPLY)
                //   tv_video_mute.text = "unmute"
            }
            it.muteLocalVideoStream(iv.isSelected)

            // in case of video...
            //  val surfaceView = fl_local_video_view_container.getChildAt(0) as SurfaceView
            //  surfaceView.setZOrderMediaOverlay(!view.isSelected)
            //  surfaceView.visibility = if (view.isSelected) View.GONE else View.VISIBLE
        }
    }

    fun onEncCallClicked(@Suppress("UNUSED_PARAMETER") view: View) {
        setCallState(EnumUtils.CallState.DISCONNECTED.value)
        sendNotification(EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value, "Video Call")
        audioCallRateReviewDialog!!.show()

    }

    override fun onReviewSubmitClick() {
        audioCallRateReviewDialog!!.dismiss()
        finish()
    }

    override fun onReviewCancelClick() {
        audioCallRateReviewDialog!!.dismiss()
        finish()
    }


    fun onSwitchCameraClicked(@Suppress("UNUSED_PARAMETER") view: View) {
        mRtcEngine?.switchCamera()
    }

    private fun checkSelfPermission(permission: String, requestCode: Int): Boolean {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, requestCode)
            return false
        }
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            RC_PERM_CALL -> {
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED || grantResults[1] != PackageManager.PERMISSION_GRANTED) {
                    when (callStatus) {
                        EnumUtils.CallStatus.INCOMING -> Toast.makeText(
                            this,
                            "Please provide required permission to receive this call",
                            Toast.LENGTH_LONG
                        ).show()
                        EnumUtils.CallStatus.OUTGOING -> Toast.makeText(
                            this,
                            "Please provide required permission to make a call",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    when (callType) {
                        EnumUtils.CallType.VIDEO_CALL -> sendNotification(
                            EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value,
                            "Video Call"
                        )
                        EnumUtils.CallType.AUDIO_CALL -> sendNotification(
                            EnumUtils.NotificationType.AUDIO_CALL_DISCONNECT.value,
                            "Audio Call"
                        )
                    }
                    finish()
                    return
                }
                initAgoraEngineAndJoinChannel()
            }
        }
    }

    private fun initAgoraEngineAndJoinChannel() {
        initializeAgoraEngine()
        when (callType) {
            EnumUtils.CallType.VIDEO_CALL -> {
//                mRtcEngine?.setDefaultAudioRoutetoSpeakerphone(true)
                mRtcEngine?.setEnableSpeakerphone(true)
                iv_back_image.visibility = View.GONE
                setupVideoProfile()
                setupLocalVideo()
            }
            EnumUtils.CallType.AUDIO_CALL -> {
//                mRtcEngine?.setDefaultAudioRoutetoSpeakerphone(false)
                iv_back_image.visibility = View.VISIBLE
                mRtcEngine?.setEnableSpeakerphone(false)
            }
        }
        joinChannel()
    }

    private fun setupVideoProfile() {
        mRtcEngine?.enableVideo()
        mRtcEngine?.setVideoEncoderConfiguration(
            VideoEncoderConfiguration(
                VideoEncoderConfiguration.VD_1280x720,
                VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,
                VideoEncoderConfiguration.STANDARD_BITRATE,
                VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_FIXED_PORTRAIT
            )
        )
    }

    private fun setupLocalVideo() {
        mRtcEngine?.enableLocalVideo(true)
        val surfaceView = RtcEngine.CreateRendererView(baseContext)
        surfaceView.setZOrderMediaOverlay(true)
        fl_local_video_view_container.addView(surfaceView)
        mRtcEngine?.setupLocalVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, 0))
    }

    private fun joinChannel() {
        //getString(R.string.agora_access_token)
        mRtcEngine?.joinChannel(null, channelName, "Extra Optional Data", 0)
    }

    private fun initializeAgoraEngine() {
        try {
            mRtcEngine = RtcEngine.create(baseContext, getString(R.string.agora_app_id), rtcEventHandler)
        } catch (e: Exception) {
            Log.e(TAG, Log.getStackTraceString(e))
            finish()
        }

        Handler().postDelayed({

            sendNotification(EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value, "Video Call")
            sendNotification(EnumUtils.NotificationType.AUDIO_CALL_DISCONNECT.value, "Audio Call")
            finish()
        }, 100000)

    }

    override fun onResume() {
        super.onResume()
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.VIDEO_CALL_ACCEPT.value))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.VIDEO_CALL_REJECT.value))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value))

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.AUDIO_CALL_ACCEPT.value))

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.AUDIO_CALL_REJECT.value))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.AUDIO_CALL_DISCONNECT.value))

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.A2V_SWAP_REQ_INCOMING.value))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.A2V_SWAP_REQ_ACCEPT.value))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(broadcastReceiver, IntentFilter(EnumUtils.NotificationType.A2V_SWAP_REQ_REJECT.value))
    }

    override fun onPause() {
        callAccept = true
        super.onPause()
        audioCallRateReviewDialog!!.dismiss()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver)
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            mp.stop()
            when (intent.action) {
                EnumUtils.NotificationType.AUDIO_CALL_ACCEPT.value -> {
                    chronometer.visibility = View.VISIBLE
                    tv_call_status.text = getString(R.string.duration)
                    //dtmfGenerator.stopTone()
                }
                EnumUtils.NotificationType.VIDEO_CALL_ACCEPT.value -> {
                    //dtmfGenerator.stopTone()
                }
                EnumUtils.NotificationType.VIDEO_CALL_REJECT.value,
                EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value,
                EnumUtils.NotificationType.AUDIO_CALL_REJECT.value,
                EnumUtils.NotificationType.AUDIO_CALL_DISCONNECT.value -> {
                    setCallState(EnumUtils.CallState.DISCONNECTED.value)
                    //dtmfGenerator.stopTone()
                    Toast.makeText(this@AudioVideoCallActivity, "$otherName disconnected the call", Toast.LENGTH_SHORT)
                        .show()
                    finish()
                }
            }
        }
    }

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        /**
         * callback is triggered upon receiving and successfully decoding the first frame of the remote video
         */
        override fun onFirstRemoteVideoDecoded(uid: Int, width: Int, height: Int, elapsed: Int) {
            runOnUiThread {
                setupRemoteVideo(uid)
            }
        }

        /**
         * notifies the application that another (remote) user with [uid] has joined the channel
         */
        override fun onUserJoined(uid: Int, elapsed: Int) {
            super.onUserJoined(uid, elapsed)
            Log.d(TAG, "onUserJoined() >> uid: $uid \n elapsed : $elapsed")
            runOnUiThread {
                iv_voice_call_mute.isEnabled = true
                iv_video_call_mute.isEnabled = true
                chronometer.visibility = View.VISIBLE
                tv_call_status.text = getString(R.string.duration)
                chronometer.base = SystemClock.elapsedRealtime()
                chronometer.start()
            }
        }

        /**
         * @param channel Channel Name for the current session
         * @param uid Unique identifier assigned to current (self) user
         * @param elapsed Elapsed Time i guess.
         *
         * Callback function to notify that current (self) user has joined the [channel]
         * with unique identifier [uid]
         */
        override fun onJoinChannelSuccess(channel: String, uid: Int, elapsed: Int) {
            super.onJoinChannelSuccess(channel, uid, elapsed)
            Log.d(TAG, "onJoinChannelSuccess() channel: $channel")
            Log.d(TAG, "onJoinChannelSuccess() uid: $uid")
        }

        /**
         * callback to notify the application that the user (self) has successfully left the channel.
         */
        override fun onLeaveChannel(stats: RtcStats?) {
            super.onLeaveChannel(stats)
            Log.d(TAG, "onLeaveChannel()")
        }

        /**
         * notifies the application that a user (remote) has left the channel or is offline.
         */
        override fun onUserOffline(uid: Int, reason: Int) {
            Log.d(TAG, "onUserOffline()")
            runOnUiThread {
                onRemoteUserLeft()
            }
        }

        override fun onUserMuteAudio(uid: Int, muted: Boolean) {
            super.onUserMuteAudio(uid, muted)
            runOnUiThread { onRemoteUserAudioMuted(uid, muted) }
        }

        /**
         * callback indicates that some other user (remote) has paused/resumed his/her video stream.
         */
        override fun onUserMuteVideo(uid: Int, muted: Boolean) {
            runOnUiThread { onRemoteUserVideoMuted(uid, muted) }
        }

        /**
         * callback indicates that some other user has enabled/disabled the video function.
         * Disabling the video function means that the user can only use voice call,
         * can neither show/send their own videos nor receive or display videos from other people.
         */
        override fun onUserEnableVideo(uid: Int, enabled: Boolean) {
            super.onUserEnableVideo(uid, enabled)
            Log.d(TAG, "onUserEnableVideo => uid : $uid , enabled : $enabled")
        }

        /**
         * callback indicates that some other user has enabled/disabled the local video function.
         */
        override fun onUserEnableLocalVideo(uid: Int, enabled: Boolean) {
            super.onUserEnableLocalVideo(uid, enabled)
            Log.d(TAG, "onUserEnableLocalVideo => uid : $uid , enabled : $enabled")
        }

        override fun onConnectionLost() {
            super.onConnectionLost()
            Log.d(TAG, "onConnectionLost()")
        }

        override fun onRejoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            super.onRejoinChannelSuccess(channel, uid, elapsed)
            Log.d(TAG, "onRejoinChannelSuccess()")
        }
    }

    private fun setupRemoteVideo(uid: Int) {
        if (fl_remote_video_view_container.childCount >= 1) {
            return
        }
        val surfaceView = RtcEngine.CreateRendererView(baseContext)
        fl_remote_video_view_container.addView(surfaceView)
        mRtcEngine?.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, uid))
        tv_connecting.visibility = View.GONE
        surfaceView.tag = uid // for mark purpose
    }

    private fun onRemoteUserLeft() {
        //ToastUtils.show(this, "$otherName disconnected the call")
        fl_remote_video_view_container.removeAllViews()
        finish()
    }

    private fun onRemoteUserAudioMuted(uid: Int, muted: Boolean) {
//        if (muted) {
//            ToastUtils.show(this, "$otherName muted the call")
//        } else {
//            ToastUtils.show(this, "$otherName unmuted the call")
//        }
    }

    private fun onRemoteUserVideoMuted(uid: Int, muted: Boolean) {
//        if (muted) {
//            ToastUtils.show(this, "$otherName muted the call")
//        } else {
//            ToastUtils.show(this, "$otherName unmuted the call")
//        }

        val surfaceView = fl_remote_video_view_container.getChildAt(0) as SurfaceView
        val tag = surfaceView.tag
        if (tag != null && tag as Int == uid) {
            surfaceView.visibility = if (muted) View.GONE else View.VISIBLE
        }
    }

    private fun showIncomingCallDialog() {
        handler.postDelayed({
            if (!callAccept) {
                mp.stop()
                incomingCallDialog!!.dismiss()

                unbindService(mConnection)
                setCallState(EnumUtils.CallState.DISCONNECTED.value)
                when (callType) {
                    EnumUtils.CallType.VIDEO_CALL -> sendNotification(
                        EnumUtils.NotificationType.VIDEO_CALL_DISCONNECT.value,
                        "Video Call"
                    )
                    EnumUtils.CallType.AUDIO_CALL -> sendNotification(
                        EnumUtils.NotificationType.AUDIO_CALL_DISCONNECT.value,
                        "Audio Call"
                    )
                }
                finish()
            }
        }, 30000)

        Intent(this, AudioService::class.java).also { intent ->
            bindService(intent, mConnection, Context.BIND_AUTO_CREATE)
        }

        incomingCallDialog = Dialog(this)
        incomingCallDialog!!.setContentView(R.layout.popup_calling_layout)
        incomingCallDialog!!.setCanceledOnTouchOutside(false)
        incomingCallDialog!!.tvCallingText.text = "$otherName is Calling You"

        Handler().postDelayed({
            mp.start()

        }, 3000)
        mp.start()

        setCallState(EnumUtils.CallState.RINGING.value)

        incomingCallDialog!!.btnStartCall.setOnClickListener {
            callAccept = true
            mp.stop()
            incomingCallDialog!!.dismiss()

            unbindService(mConnection)

            setCallState(EnumUtils.CallState.CONNECTED.value)

            when (callType) {
                EnumUtils.CallType.VIDEO_CALL -> sendNotification(
                    EnumUtils.NotificationType.VIDEO_CALL_ACCEPT.value,
                    "Video Call"
                )
                EnumUtils.CallType.AUDIO_CALL -> sendNotification(
                    EnumUtils.NotificationType.AUDIO_CALL_ACCEPT.value,
                    "Audio Call"
                )
            }

            if (checkSelfPermission(
                    REQUESTED_PERMISSIONS[0],
                    RC_PERM_CALL
                ) && checkSelfPermission(REQUESTED_PERMISSIONS[1], RC_PERM_CALL)
            ) {
                initAgoraEngineAndJoinChannel()
            }
        }

        incomingCallDialog!!.btnEndCall.setOnClickListener {
            callAccept = true
            mp.stop()
            incomingCallDialog!!.dismiss()

            unbindService(mConnection)
            setCallState(EnumUtils.CallState.DISCONNECTED.value)
            when (callType) {
                EnumUtils.CallType.VIDEO_CALL -> sendNotification(
                    EnumUtils.NotificationType.VIDEO_CALL_REJECT.value,
                    "Video Call"
                )
                EnumUtils.CallType.AUDIO_CALL -> sendNotification(
                    EnumUtils.NotificationType.AUDIO_CALL_REJECT.value,
                    "Audio Call"
                )
            }
            finish()
        }

        incomingCallDialog!!.show()
        incomingCallDialog!!.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun sendNotification(notifcationType: String, callType: String) {
        var id = otherId

        if (otherId == null) return
        val name = SharedPreferenceUtil.getInstance(this).userName
        if (NetworkUtils.isInternetAvailable(this)) {
            //progressDialog.showProgress()
            verificationDisposable = apiService.sendCallNotification(
                accessToken = SharedPreferenceUtil.getInstance(this).accessToken,
                send_to_id = otherId!!.replace("u_", ""),
                title = callType,
                notification_type = notifcationType,
                call_id = callId!!,
                message = "$name is calling",
                full_name = "Mayank",
                profile_pic = "ABCD"
            ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe({ onVerificationSuccess(it) },
                    { onverificationError(it) })
        } else {
            Toast.makeText(this, "Please check you internet connectivity", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onverificationError(throwable: Throwable) {
        // progressDialog.hideProgress()
        ErrorUtil.handlerGeneralError(this, activity_video_chat_view, throwable)
        throwable.printStackTrace()

        when (throwable) {
            is HttpException -> {
                if (throwable.code() == 401) {
                    // SharedPreferenceUtil.getInstance(this!!).isLoggedIn=false
                    startActivity(Intent(this, LoginActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    finish()
                } else {
                }
            }
        }
    }

    private fun onVerificationSuccess(response: NotificationRes) {
        if (callHandle) {
            callHandler()

            callHandle = false
        }
    }

    private fun callHandler() {
        val handler = Handler()
        handler.postDelayed({
            FirebaseDatabase.getInstance().reference
                .child("Call")
                .child(callId!!)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.exists()) {
                            val oneCallDetail = dataSnapshot.getValue(OneCallDetail::class.java)
                            oneCallDetail?.let { mCallDetail ->
                                val value = mCallDetail.call_status
                                if (value.equals("0")) {
                                    FirebaseDatabase.getInstance().reference.child("Call")
                                        .child(callId!!)
                                        .child("call_status")
                                        .setValue("4")
                                }
                            }
                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {

                    }
                })
        }, 30000)
    }

    private fun resetViewsVisibility() {
        iv_voice_call_mute.visibility = if (isVideoCall()) View.GONE else View.VISIBLE
        fl_user_image.visibility = if (isVideoCall()) View.GONE else View.VISIBLE
        rl_back_img.visibility = if (isVideoCall()) View.GONE else View.VISIBLE
        tv_user_name.visibility = if (isVideoCall()) View.GONE else View.VISIBLE
        tv_call_status.visibility = if (isVideoCall()) View.GONE else View.VISIBLE
        chronometer.visibility = if (isVideoCall()) View.VISIBLE else View.GONE
        fl_remote_video_view_container.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        fl_local_video_view_container.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        iv_video_call_mute.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        iv_camera_swap.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        //  tv_video_mute.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        //  tv_camera_swap.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
        tv_connecting.visibility = if (isVoiceCall()) View.GONE else View.VISIBLE
    }

    override fun initControl() {
    }

    override fun onClick(v: View?) {
        onSwitchToVideoCallClicked(view = View(this))
    }

    fun setCallState(callState: String) {
        FirebaseDatabase.getInstance().reference.child("Call").child(callId!!)
            .child("call_status")
            .setValue(callState)
    }
}