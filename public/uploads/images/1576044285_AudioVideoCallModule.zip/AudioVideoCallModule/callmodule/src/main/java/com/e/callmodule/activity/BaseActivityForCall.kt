package com.e.callmodule.activity

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.util.Log
import com.e.callmodule.utils.RetrofitUtil

@SuppressLint("Registered")
abstract class BaseActivityForCall : AppCompatActivity() {
    companion object {
        var TAG = BaseActivityForCall::class.simpleName
        var CURRENT_USER=null
    }
    // var gsonInstance: Gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  BundleUtils.printIntentData(TAG, intent)
        // FirebaseUtils.logFirebaseToken()
    }

    val apiService by lazy { RetrofitUtil.apiService() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d(TAG, "onActivityResult requestCode: $requestCode")
        Log.d(TAG, "onActivityResult resultCode: $resultCode")
        // BundleUtils.printIntentData(TAG, data)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.d(TAG, "onRequestPermissionsResult requestCode: $requestCode")
        permissions.indices.forEach { Log.d(TAG, "onRequestPermissionsResult permissions[$it] : ${permissions[it]}") }
        permissions.indices.forEach { Log.d(TAG, "onRequestPermissionsResult grantResults[" + it + "] : " + grantResults[it]) }
    }

    // https://stackoverflow.com/a/10261449/2437655 or check alex lockwood answer on the commitAllowingStateLoss
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("WORKAROUND_FOR_BUG_19917_KEY", "WORKAROUND_FOR_BUG_19917_VALUE")
        super.onSaveInstanceState(outState)
    }

    /*  override fun attachBaseContext(newBase: Context) {
          super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
      }*/

    abstract fun init(savedInstanceState: Bundle?)

    abstract fun initControl()


}