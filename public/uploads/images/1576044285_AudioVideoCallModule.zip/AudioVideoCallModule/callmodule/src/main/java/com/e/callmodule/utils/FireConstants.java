package com.e.callmodule.utils;

import com.e.callmodule.constant.StatusType;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


//This class contains FireBase database refs
public class FireConstants {
    private static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    public static final DatabaseReference mainRef = database.getReference();

    public static DatabaseReference getMyStatusRef(int type) {
        if (type == StatusType.TEXT)
            return textStatusRef.child(FireManager.getUid());
        else
            return statusRef.child(FireManager.getUid());
    }

    //All statuses goes here
    public static final DatabaseReference statusRef = mainRef.child("status");
    public static final DatabaseReference textStatusRef = mainRef.child("textStatus");
}