package com.e.callmodule.response

data class RegistrationRes(
    var `data`: Data,
    var message: String
) {
    data class Data(
        var country_code: String,
        var id: Int,
        var email: String,
        var first_name: String,
        var is_mail_verify: Boolean,
        var is_num_verify: Boolean,
        var last_name: String,
        var mobile_number: String,
        var token: String,
        var profile_image: String
    )
}