package com.e.callmodule.utils

class  EnumUtils {

    val TAG = EnumUtils::class.simpleName

    enum class DeviceType(val value: String) {
        ANDROID("1"), IOS("2")

    }

    enum class profile_type(val value: String) {
        PERSONAL("1"), COMPANY("2")

    }

    enum class SignUpType(val value: String) {
        NORMAL_SIGNUP("0"), SOCIAL_SIGNUP("1")

    }

    enum class GenderType(val value: String) {
        MALE("M"), FEMALE("F"), OTHERS("O")

    }

    enum class account_type(val value: String) {
        NORMAL("1"), FACEBOOK("2"), INSTAGRAM("3"), SNAPCHAT("4"),
        TWITTER("5"), GOOGLE("6")

    }

    enum class NotificationType(val value: String) {
        VIDEO_CALL_INCOMING("VIDEO_CALL_INCOMING"),
        VIDEO_CALL_DISCONNECT("VIDEO_CALL_DISCONNECT"),
        VIDEO_CALL_REJECT("VIDEO_CALL_REJECT"),
        VIDEO_CALL_ACCEPT("VIDEO_CALL_ACCEPT"),
        GROUP_VIDEO_CALL_INCOMING("GROUP_VIDEO_CALL_INCOMING"),
        GROUP_VIDEO_CALL_DISCONNECT("GROUP_VIDEO_CALL_DISCONNECT"),
        GROUP_VIDEO_CALL_ACCEPT("GROUP_VIDEO_CALL_ACCEPT"),
        GROUP_VIDEO_CALL_REJECT("GROUP_VIDEO_CALL_REJECT"),

        AUDIO_CALL_INCOMING("AUDIO_CALL_INCOMING"),
        AUDIO_CALL_DISCONNECT("AUDIO_CALL_DISCONNECT"),
        AUDIO_CALL_REJECT("AUDIO_CALL_REJECT"),
        AUDIO_CALL_ACCEPT("AUDIO_CALL_ACCEPT"),
        GROUP_AUDIO_CALL_INCOMING("GROUP_AUDIO_CALL_INCOMING"),
        GROUP_AUDIO_CALL_DISCONNECT("GROUP_AUDIO_CALL_DISCONNECT"),
        GROUP_AUDIO_CALL_ACCEPT("GROUP_AUDIO_CALL_ACCEPT"),
        GROUP_AUDIO_CALL_REJECT("GROUP_AUDIO_CALL_REJECT"),

        A2V_SWAP_REQ_INCOMING("A2V_SWAP_REQ_INCOMING"),
        A2V_SWAP_REQ_REJECT("A2V_SWAP_REQ_REJECT"),
        A2V_SWAP_REQ_ACCEPT("A2V_SWAP_REQ_ACCEPT"),

        CLUB_REQUEST_ACCEPTED("CLUB_REQUEST_ACCEPTED"),
        CLUB_REQUEST_REJECTED("CLUB_REQUEST_REJECTED"),

        USER_REQUEST_ACCEPTED("USER_REQUEST_ACCEPTED"),

        CHAT_NOTIFICATION("CHAT_NOTIFICATION")
    }

    enum class CallStatus(val value: String) {
        INCOMING("0"),
        OUTGOING("1")
    }

    enum class CallState(val value: String) {
        CONNECTING("0"),
        RINGING("1"),
        CONNECTED("2"),
        REJECTED("3"),
        DISCONNECTED("4"),
        NOT_ANSWERED("5")
    }

    enum class CallType(val value: String) {
        VIDEO_CALL("0"),
        AUDIO_CALL("1"),
        GROUP_VIDEO_CALL("2"),
        GROUP_AUDIO_CALL("3")
    }

    enum class CartActionType {
        PLUS, MINUS

    }

    enum class SortType {
        NONE, PRICE_HIGH_TO_LOW, PRICE_LOW_TO_HIGH, POPULAR, LATEST_ADDED, BEST_RATED

    }


    enum class MONTHS { Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec }
}