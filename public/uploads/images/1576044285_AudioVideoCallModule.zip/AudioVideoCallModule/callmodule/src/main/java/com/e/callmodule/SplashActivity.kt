package com.e.callmodule

import android.Manifest
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.e.callmodule.activity.AudioVideoCallActivity
import com.e.callmodule.constant.BundleConstants
import com.e.callmodule.constant.StatusType
import com.e.callmodule.model.OneCallDetail
import com.e.callmodule.utils.EnumUtils
import com.e.callmodule.utils.FireConstants
import com.google.firebase.database.FirebaseDatabase
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions
import kotlinx.android.synthetic.main.activity_splash.*
import java.util.ArrayList

class SplashActivity : AppCompatActivity(), View.OnClickListener {
    private var callId = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        initViews()
        initContRole()
    }

    private fun initViews() {
        callId = FireConstants.getMyStatusRef(StatusType.TEXT).push().key!!
    }

    //All controls define here
    private fun initContRole() {
        tvAudio.setOnClickListener(this)
        tvVideo.setOnClickListener(this)
        tvGroupAudio.setOnClickListener(this)
        tvGroupVideo.setOnClickListener(this)
    }

    //OnClick Listener
    override fun onClick(v: View) {
        when (v.id) {
            R.id.tvAudio -> {
                oneToOneAudio()
            }

            R.id.tvVideo -> {
                oneToOneVideo()
            }

            R.id.tvGroupAudio -> {
                groupAudio()
            }

            R.id.tvGroupVideo -> {
                groupVideo()
            }
        }
    }

    //One To One Audio Call
    private fun oneToOneAudio() {
        Permissions.check(this/*context*/, Manifest.permission.RECORD_AUDIO, null, object : PermissionHandler() {
            //Permission Granted
            override fun onGranted() {
                addSingleCallToFireBase("0", "4")//callType 1 = video call, 0 = audio call & receiverUid
                val intent = Intent(this@SplashActivity, AudioVideoCallActivity::class.java)
                intent.putExtra(BundleConstants.KEY_OTHER_ID, "4") //Friend Id
                intent.putExtra(BundleConstants.KEY_OTHER_NAME, "Mayank") //Friend Name
                intent.putExtra(BundleConstants.KEY_CALL_ID, callId) //Call Id
                intent.putExtra(BundleConstants.KEY_OTHER_AVATAR, " ")
                intent.putExtra(BundleConstants.KEY_CALL_TYPE, EnumUtils.CallType.AUDIO_CALL) //Call Type
                intent.putExtra(BundleConstants.KEY_CALL_STATUS, EnumUtils.CallStatus.OUTGOING) //Call Status
                startActivity(intent)
            }

            //Permission Denied
            override fun onDenied(context: Context, deniedPermissions: ArrayList<String>) {
                Toast.makeText(this@SplashActivity, "Need permission for audio call", Toast.LENGTH_SHORT).show()
            }
        })
    }

    //One To One Vide  Call
    private fun oneToOneVideo() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO
        )
        Permissions.check(this/*context*/, permissions, null/*options*/, null, object : PermissionHandler() {
            //Permission Granted
            override fun onGranted() {
                addSingleCallToFireBase("1", "4")  //callType 1 = video call, 0 = audio call
                val intent = Intent(this@SplashActivity, AudioVideoCallActivity::class.java)
                intent.putExtra(BundleConstants.KEY_OTHER_ID, "4")  //Friend Id
                intent.putExtra(BundleConstants.KEY_OTHER_NAME, "Mayank")  //Friend Name
                intent.putExtra(BundleConstants.KEY_CALL_ID, callId) //Call Id
                intent.putExtra(BundleConstants.KEY_OTHER_AVATAR, " ")
                intent.putExtra(BundleConstants.KEY_CALL_TYPE, EnumUtils.CallType.VIDEO_CALL)  //Call Id
                intent.putExtra(BundleConstants.KEY_CALL_STATUS, EnumUtils.CallStatus.OUTGOING)  //Call Status
                startActivity(intent)
            }

            //Permission Denied
            override fun onDenied(context: Context, deniedPermissions: ArrayList<String>) {
                Toast.makeText(this@SplashActivity, "Need permission for video call", Toast.LENGTH_SHORT).show()
            }
        })
    }

    //Group Audio Call
    private fun groupAudio() {

    }

    //Group Video Call
    private fun groupVideo() {

    }

    //Add Call Details to the FireBase
    private fun addSingleCallToFireBase(callType: String, friendID: String) {
        callId = FireConstants.getMyStatusRef(StatusType.TEXT).push().key!!
        val childUpdates = OneCallDetail(
            friendID, //Friend Id
            callId, //Call Id
            callType,  //Call Type
            "Friend Name Call",  //Call Status
            "0", //Call Status
            System.currentTimeMillis() //Current TimeMillis
        )

        FirebaseDatabase.getInstance().getReference("Call").child(callId).setValue(childUpdates)
            .addOnSuccessListener { Toast.makeText(this@SplashActivity, "Call Data Load", Toast.LENGTH_SHORT).show() }
    }
}