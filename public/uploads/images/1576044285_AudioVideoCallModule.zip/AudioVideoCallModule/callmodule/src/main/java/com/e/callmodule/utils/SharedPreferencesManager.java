package com.e.callmodule.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SharedPreferencesManager {

    //this will contains the app preferences
    private static SharedPreferences mSharedPref;

    public static String getUid() {
        return mSharedPref.getString("uid", "");
    }

    synchronized public static void init(Context context) {
        if (mSharedPref == null)
            mSharedPref = PreferenceManager.getDefaultSharedPreferences(context);
    }
}