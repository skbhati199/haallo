package com.e.callmodule.constant;

public class StatusType {
    public static final int IMAGE = 1;
    public static final int VIDEO = 2;
    public static final int TEXT = 3;
}
