package com.e.callmodule.response

data class NotificationRes(
    var message: String

)