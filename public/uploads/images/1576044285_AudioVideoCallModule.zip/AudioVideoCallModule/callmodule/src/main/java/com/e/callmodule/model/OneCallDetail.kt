package com.e.callmodule.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class OneCallDetail(
    var friendid:String="",
    var call_id: String = "",
    var call_type: String="",
    var message: String="",
    var call_status: String="",
    var timeStamp: Long = 0L

) : Parcelable